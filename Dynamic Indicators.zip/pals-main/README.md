# pals
It contains the monthly exposures code
